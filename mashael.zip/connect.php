<?php

$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "shop";  
// Check connection


$conn_shop = mysqli_connect($servername, $username, $password, $dbname);?>


          



