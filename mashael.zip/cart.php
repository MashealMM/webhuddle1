   <?php    include('head.php');
         include('connect.php');

 
    
class basket {
function add($pid,$qty){


if(!isset($_SESSION['basket'])){
$_SESSION['basket']=array();
$_SESSION['basket'][0]['productid']=$pid;
$_SESSION['basket'][0]['qty']=$qty;
echo 'تم اضافة السلعة';
}

else {

if($this->isexist($pid,$qty)){
echo 'تم اتحديث الكمية';
}
else{
$m=$_SESSION['basket'];
$max=count($m);
$_SESSION['basket'][$max]['productid']=$pid;
$_SESSION['basket'][$max]['qty']=$qty;
echo 'تم اضافة السلعة';
}
}

}

function isexist($pid,$qty) {
$m=$_SESSION['basket'];
$max=count($m);
for($i=0;$i<$max;$i++){
if($pid==$_SESSION['basket'][$i]['productid']){
$_SESSION['basket'][$i]['qty']=$qty;
return true;break;}
}
return false;}

function delete($pid){
$m=$_SESSION['basket'];
$max=count($m);
for($i=0;$i<$max;$i++){
if($pid==$_SESSION['basket'][$i]['productid']){
unset($_SESSION['basket'][$i]);
$_SESSION['basket']=array_values($_SESSION['basket']);$_SESSION['basket'.'num']-=1;
break;}
}
}


function modify($pid,$qty){
$m=$_SESSION['basket'];
$max=count($m);
if($qty>0){
for($i=0;$i<$max;$i++){
if($pid==$_SESSION['basket'][$i]['productid']){
$_SESSION['basket'][$i]['qty']=$qty;break;}
}
}
else $this->delete($pid);


}

function show_basket() {

$max=count($_SESSION['basket']);
for($i=0;$i<$max;$i++){
echo 'id=>'.$_SESSION['basket'][$i]['productid'].'qty=>'.$_SESSION['basket'][$i]['qty'];
}
}

}    
 ?>