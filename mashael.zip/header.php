<!DOCTYPE html>
<html>
   <head>

      <link rel="Shorticon" href="http://www.ghrix.com/wp-content/uploads/2016/07/shopify-1.png">
      <link rel="stylesheet" type="text/css" href="../Mashealm/rec/css/adi.css">
      <title>My shop</title>
      <link href="../Mashealm/rec/css/adi.css" rel="stylesheet"/>
      <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
      <link href="https://fonts.googleapis.com/css?family=Courgette" rel="stylesheet">
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script></head>
      <script>
         function alertmsg(){
         $(".bacg").fadeIn();  }
         
         
         
         $(document).ready(function(){
         
         $(".bacg").click(function(){
         
         $(".bacg").fadeOut();
         
         });
         
         });
         
      </script>
   <body>
      <div class="bacg">
         <div class="mag">
            <h4>The item added to cart</h4>
         </div>
      </div>
      <div class="bg left">  </div>
      <div class="bg right">  </div>
     
      <header class="w3-content" class="col-xs-12 col-md-8">
         <div class="h-top" class="col-xs-12 col-md-8">
            <div class="search-box-m" class="col-xs-12 col-md-8">
               <input type="text" name="search" placeholder="Search..">
            </div>
            <div class="h-buttom" class="col-xs-12 col-md-8">
               <ul>
                  <li class="lest-right" ><a href="#"><img class="cart" src="https://image.flaticon.com/icons/svg/166/166170.svg"></a></li>
                  <li class="lest-right"><a href="Sign_Up.php">log up</a></li>
                  <li class="lest-right"><a class="active" href="Login.php">log in</a></li>
               </ul>
            </div>
            <div class="logoo"> 
            </div>
         </div>
      </header>
      <nav class="w3-content">
  <ul>
            <li class="dropdown">
               <a href="javascript:void(0)" class="dropbtn">We arrived recently</a>
            </li>
            <li class="dropdown">
               <a href="javascript:void(0)" class="dropbtn">Women</a>
               <div class="dropdown-content">
                   <img src="https://ss.tidebuy.com/images/product/c/5581/12194/12194435_1.jpeg">
                  <img src="http://img.yasmina.com/GLscbHZaynPFR9b7Z4U29Z0dXQ8=/800x0/smart/http://harmony-assets-live.s3.amazonaws.com/image_source/02/75/02756145a0cb264a045e35ffc2ba5f4020f11399.jpg">
                 <img src="https://i.pinimg.com/736x/b6/58/0b/b6580b4fef4d4b85eff2d58a2bc3ce2b--burberry-handbags-chanel-handbags.jpg">
               </div>
            </li>
            <li class="dropdown">
               <a href="javascript:void(0)" class="dropbtn">children</a>
               <div class="dropdown-content">
                  <img src="http://www.huluonline.com/images/2016/03/932-2-or-1459431678.jpg">
                  <img src="https://www.hsreat.com/attachments/112-jpg.53929/">
               </div>
            </li>
            <li class="dropdown">
               <a href="javascript:void(0)" class="dropbtn">Men</a>
               <div class="dropdown-content">
                  <img src="http://premiumcard.net/cms/image_resize/image_resize.php?image=/cms/files/1372082471menwear_image_b.jpg&width=235&height=290&cropratio=235:290">
                  <img src="https://vb.elmstba.com/imgcache/almastba.com_1381411261_170.jpeg">
               </div>
            </li>
            <li class="dropdown">
               <a href="javascript:void(0)" class="dropbtn">sport</a>
               <div class="dropdown-content">
                  <img src="https://upload.3dlat.net/uploads/3dlat.com_25_2014)201407071328raj.jpg">
                  <img src="https://i.pinimg.com/originals/81/6a/7b/816a7b9fe6bf2d354a32c131b9a227ec.jpg">
                  <img src="http://g01.a.alicdn.com/kf/HTB12fSrMVXXXXcqXFXXq6xXFXXXu/-font-b-Great-b-font-font-b-Men-b-font-Winter-Snow-font-b-Boots.jpg">
               </div>
            </li>
         </ul>
         <div class="w3-content w3-section" >
            <img class="mySlides" src="https://dnc2qm9v6i95t.cloudfront.net/cache/Homepage/1341/2017_04_13_05_29_27/1492061367-710x290.jpg" >
            <img class="mySlides" src="https://1.bp.blogspot.com/-OsuKZrEKHOk/Vp99ra_4NBI/AAAAAAAAAlU/32SNF84PF3Q/s400/images%2B%25281%2529.jpg">
            <img class="mySlides" src="https://www.supermama.me/sites/default/files/styles/main_article_style_watermark/public/field/image/%D8%AA%D8%AE%D9%81%D9%8A%D8%B6%D8%A7%D8%AA-%D8%AC%D8%AF%D9%8A%D8%AF%D8%A9.jpg?itok=y651YrZ5" >
            <img class="mySlides" src='http://n4hr.org/up/uploads/n4hr_13461123244.jpg' >
            <img class="mySlides"  src="http://img.youm7.com/Albums/albumimages/1020151461873491.jpg">
            <img class="mySlides" src="https://b.wadicdn.com/cms/phoenix/assortment/dkFor-Women_ar.jpg">
            <img class="mySlides" src="http://arabyshop.com/wp-content/uploads/2016/02/%D9%85%D9%84%D8%A7%D8%A8%D8%B3-%D8%A3%D8%B7%D9%81%D8%A7%D9%84.jpg">
            <img class="mySlides" src='https://www.supermama.me/sites/default/files/styles/main_article_style_watermark/public/%D8%AA%D8%AE%D9%81%D9%8A%D8%B6%D8%A7%D8%AA-%D9%85%D9%84%D8%A7%D8%A8%D8%B3-%D8%A7%D9%84%D8%B9%D9%8A%D8%AF.jpg?itok=y-AQ4cgD'>
            <img class="mySlides" src='https://upload.3dlat.net/uploads/3dlat.net_30_16_f168_b231e98929e12.jpg'>
            <img class="mySlides" src='http://www.arab-lady.com/wp-content/uploads/2015/03/143758866413.jpg'>
            <img class="mySlides" src='http://www.hayah.cc/forum/hayahimgcache/1/51103hayah.jpg' >
            <img class="mySlides" src="http://img.el-wlid.com/imgcache/2016/01/1058005.jpg">
            <img class="mySlides" src="http://s3.amazonaws.com/mbc_actionha/uploads/52170/large.jpg">
         </div>
         </nav>
         </body></html>