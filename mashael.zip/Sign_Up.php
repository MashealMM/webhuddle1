 <?php

include('connect.php');


?>
<!DOCTYPE HTML>  
<html>
<link rel="stylesheet" type="text/css"   href="rec/css/css.css">
<body>


<div class="container">
<?php


     $result = " SELECT * FROM leaseds ";

  $selected = mysqli_query($conn_Id,$result);

   while($row = mysqli_fetch_assoc($selected)){


   $ID_number1 =  $row['ID_number'];
  

  }

   if(isset($_POST['submit'])){


$userName =$_POST["userName"];
$email =$_POST['email'];
$password =$_POST["password"];
$Password_confirmation=$_POST['Password_confirmation'];
$phoneNumbr	=$_POST['phoneNumbr	'];




 if (empty($userName) ||empty($email) || empty($password) ){

 	echo "<div style='color:white;width:200px;background:red;'> plaese fill the record</div>";

elseif($ID_number == $ID_number){

 	echo "<div style='color:white;width:200px;background:red;'> The ID is found</div>";

 }
 else{

 	$insert = "INSERT INTO users(userName,email,password,Password_confirmation,phoneNumbr)VALUES('$userName','$email','$password','$Password_confirmation','$phoneNumbr')";



 	  $inertok =  mysqli_query($conn_Id , $insert);


 	  if($inertok){

 	  	echo "<div style='color:white;width:200px;background:green;'>insert successfully</div>";


 	  }
 	}

 	 	
 	 	}
 	 	
 	 	?>
 	 	
 	 	<form action="Sign_Up.php" method="post">
 	 	 <label>frst Name:</label><br> <input type="text" name="frstname"  placeholder="Your name.."><br><br>
 <label>last Name:</label><br> <input type="text" name="lastname"  placeholder="Your last name.."><br><br>
 <label>Id:</label> <br><input type="text" name="ID_number"  placeholder="ID.."><br><br>
 <br><br>
<button name="submit" ><a>Register</a></button><br><br>
<button ><a href="#">Back to home</a></button>

</form>

</div>



</body>
</html>

