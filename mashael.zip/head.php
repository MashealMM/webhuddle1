<!DOCTYPE html>
<html>
   <?php    
     include('connect.php');

 ?>
  <head>
      <link rel="stylesheet" type="text/css"   href="rec/css/bootstrap.min.css">
      <link rel="Short icon" href="http://www.ghrix.com/wp-content/uploads/2016/07/shopify-1.png"\>
      <link rel="stylesheet" type="text/css"   href="C:/Users/Lenovo/fruit/Desktop/Project1/css.css">

      <title>My shop</title>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
      <link href="../Mashealm/rec/css/adi.css" rel="stylesheet"/>
      <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
      <link href="https://fonts.googleapis.com/css?family=Courgette" rel="stylesheet">
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
      <script src="rec/js/.js"></script>
      <script type="text/javascript" href="rec/js/bootstrap.min.js"></script></head>
      <script>

    
         function alertmsg(){
         $(".bacg").fadeIn();  }
         
         
         
         $(document).ready(function(){
         
         $(".bacg").click(function(){
         
         $(".bacg").fadeOut();
         
         });
         
         });
         
      </script>