<?php
	session_start();
	include 'connect.php';
	include 'header.php';

	if (!isset($_SESSION['userName'])) {
		header('location: index.php');
    	exit();
	}

if ($conn_status) {

	date_default_timezone_set('Asia/Riyadh');

	if ($_SERVER['REQUEST_METHOD']=="POST"){

		$UId = $_POST['UId'];

		$sql_stam = "SELECT * FROM `user`
								WHERE `University_ID` = '$UId'";

		$result = mysqli_query($conn_status, $sql_stam);

		if (mysqli_num_rows($result) == 1) {
			while ($row = mysqli_fetch_assoc($result)) {

            $rowid = $row['Sid'];
						echo $rowid;
            $time = time();

						// تسجيل وقت دخول الطالبة إلى النادي
            $insert_stam = "INSERT INTO `time_of_use`(`id`, `inTime`, `outTime`, `Time`, `user`) VALUES(NULL, '$time', '', '', '$rowid')";
            $test1 = mysqli_query($conn_status, $insert_stam);

						// تحديث عدد مرات دخول الطالبة إلى النادي
						$current_count = $row['timeToLogin'];
            $new_count = $current_count + 1;

            $count_stam = "UPDATE `user` SET `timeToLogin` = '$new_count' WHERE `Sid` = $rowid";
            $count_result = mysqli_query($conn_status, $count_stam);

						header('location: index.php');
						exit();
			}
		}

	}


?>

<div class="container">
	<form action="login.php" method= "POST">

        <h3 class="text-center">دخول الطالبات للنادي</h3>
        <div class="test">
            <input type="text" name="UId" placeholder="الرقم الجامعي">
        </div>
				<div class="test">
            <input type="submit" value="دخول">
        </div>

    </form>

		<!-- تسجيل طالبة جديدة ليس لديها حساب في النادي -->
		<div>
			<a href="signup.php">تسجيل طالبة جديدة</a>
		</div>

		<div>
			<h3><a href="main.php">الصفحة الرئيسية</a></h3>
		</div></div>

<?php

include 'footer.php';

}else{
    echo "No connection";
	echo  mysqli_connect_error();
}
?>
