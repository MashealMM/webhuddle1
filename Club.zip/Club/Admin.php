<!DOCTYPE HTML>  
<html>
<head>
<style >
  a {
    text-decoration: none;
    color: white;
}
table, td, th {    
    border: 1px solid #ddd;
    text-align: left;
}

table {
    border-collapse: collapse;
}

th, td {
    padding: 8px;
}
#a {
    text-decoration: none;
    text-align: center;
    color: #ffffff;
}
.comercial {
    
    width: 27%;
    margin: auto 550px;
    border-radius: 5px;}

.comercials {
    padding: 2px 19px;
    text-align: center;
    text-decoration: none;
    outline: none;
    border: none;
    background-color: rgb(111, 28, 59);}

</style>

</head> 
  <?php    include('connect.php');include('head.php');
 ?>
<body>
<div class="comercial">
<h1>Admin</h1>
<table>
  <tr>
    <th>The Name</th>
    <th>Id</th>
    <th>sinTime</th>
    <th>outTime</th>
    <th>Totil</th>
  </tr>
     <?php
              $timeOfUse_stam   = "SELECT * FROM time_of_use 
                WHERE user = '$userid' 
                ORDER BY id DESC LIMIT 1";
    $timeOfUse_result   = mysqli_query($conn_id, $timeOfUse_stam);

        while ($row = mysqli_fetch_assoc($timeOfUse_result)) {
          $sinTime   = $row['inTime'];
          $inTime   = date('h:i:s', $sinTime);
          echo $inTime;
          echo'<br>';

          $soutTime   = $row['outTime'];
          $outTime   = date('h:i:s', $soutTime);
          echo $outTime;
          echo'<br>';

          $myTime = $soutTime - $sinTime;

          $hour = $myTime / 3600 % 24;    // to get hours
      $minute = $myTime / 60 % 60;    // to get minutes
      $second = $myTime % 60;         // to get seconds

      echo $hour.':'.$minute.':'.$second;

      $updTime_stam = "UPDATE time_of_use SET Time='$myTime'
              WHERE user='$userid' 
              ORDER BY id DESC LIMIT 1";
      $useTime = mysqli_query($conn_id, $updTime_stam);

        

                  ?>
  <tr>
    <form action="Admin.php" method="post">
    <td><?php echo  $Tech_name ; ?></td>
    <td><?php echo  $ID_number ; ?></td>
    
    </form>
  </tr>

<?php  } ?>

</table>


</div>
</body>
</html>