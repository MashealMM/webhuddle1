<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
 
<link rel="stylesheet" type="text/css"   href="css.css">

    <meta charset="utf-8">
    <title></title>
    <style media="screen">
      body{direction: rtl}
      table,td{border: 1px solid #ccc}
    </style>
  </head>
  <body>
  <div class="logo">

            <a>
              <img  alt="logo" src="img/Zmz5vnoL_400x400.jpg">
            </a>
        </div>