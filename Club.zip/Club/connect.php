<?php

$servername = "localhost";
$username = "";
$password = "";
$dbname = "Masheal";
//$username = "id5741066_root";
//$dbname = "id5741066_eplanning";
	
	// Create connection
$conn_status = mysqli_connect($servername, $username, $password, $dbname);

/**/
mysqli_set_charset($conn_status,"utf8");

if (!$conn_status) {
    die("Connection failed: " . mysqli_connect_error());
}

	//	echo "Connected successfully";

?>