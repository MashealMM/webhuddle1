-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 03 سبتمبر 2018 الساعة 15:18
-- إصدار الخادم: 10.1.28-MariaDB
-- PHP Version: 7.1.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `masheal`
--

-- --------------------------------------------------------

--
-- بنية الجدول `admin`
--

CREATE TABLE `admin` (
  `Id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- إرجاع أو استيراد بيانات الجدول `admin`
--

INSERT INTO `admin` (`Id`, `name`, `password`) VALUES
(1, 'masheal', 'aa4fb2ff37224a189259ef04aac8a0827d625b61');

-- --------------------------------------------------------

--
-- بنية الجدول `time_of_use`
--

CREATE TABLE `time_of_use` (
  `id` int(11) NOT NULL,
  `inTime` varchar(255) NOT NULL,
  `outTime` varchar(255) NOT NULL,
  `Time` varchar(255) NOT NULL,
  `user` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- إرجاع أو استيراد بيانات الجدول `time_of_use`
--

INSERT INTO `time_of_use` (`id`, `inTime`, `outTime`, `Time`, `user`) VALUES
(31, '1535971392', '1535973092', '1700', 3),
(32, '1535972046', '1535973106', '1060', 4),
(34, '1535973865', '1535975578', '1713', 3),
(35, '1535975520', '1535975968', '448', 4),
(36, '1535978320', '1535978334', '14', 7),
(37, '1535978415', '1535978436', '21', 3),
(38, '1535978421', '1535978426', '5', 4),
(39, '1535978572', '1535978704', '132', 7),
(40, '1535978712', '1535979656', '944', 7);

-- --------------------------------------------------------

--
-- بنية الجدول `user`
--

CREATE TABLE `user` (
  `Sid` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `University_ID` varchar(255) NOT NULL,
  `timeToLogin` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- إرجاع أو استيراد بيانات الجدول `user`
--

INSERT INTO `user` (`Sid`, `name`, `University_ID`, `timeToLogin`) VALUES
(3, 'اسماء', '110', 2),
(4, 'مرام', '120', 2),
(7, 'masheal', '130', 3);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `time_of_use`
--
ALTER TABLE `time_of_use`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user` (`user`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`Sid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `time_of_use`
--
ALTER TABLE `time_of_use`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `Sid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- قيود الجداول المحفوظة
--

--
-- القيود للجدول `time_of_use`
--
ALTER TABLE `time_of_use`
  ADD CONSTRAINT `time_of_use_ibfk_1` FOREIGN KEY (`user`) REFERENCES `user` (`Sid`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
