<?php
	session_start();
	include 'connect.php';
	include 'header.php';

	if (isset($_SESSION['userName'])) {
		header('location: main.php');
    	exit();
	}

if ($conn_status) {

    if ($_SERVER['REQUEST_METHOD']=="POST"){
    	$user = $_POST['user'];
        $pass = $_POST['pass'];
        $hashpass = sha1($pass);

        $sql_stam = "SELECT * FROM `admin`
                    WHERE `name` = '$user'
                    AND `password` = '$hashpass'";

        $result = mysqli_query($conn_status, $sql_stam);

        if (mysqli_num_rows($result) == 1) {
			$_SESSION['userName'] = $user; // Register session name
        	header('location: main.php');
        	exit();
        }
    }

?>
	<div class="container">
<h2 class="text-center">Admin Page</h2>
	<form action="index.php" method= "POST">

        <h3 class="text-center">Admin</h3></div>
        <?php

        ?>
        <div class="test">
            <input type="text" name="user" placeholder="username">
        </div>
        <div class="test">
            <input type="password" name="pass" placeholder="password">
        </div>
        <div class="test">
            <input type="submit" value="Login">
        </div>

    </form>
</div>
         
<?php
include 'footer.php';

}else{
    echo "No connection";
	echo  mysqli_connect_error();
}
?>
