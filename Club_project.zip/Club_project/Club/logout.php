<?php

	session_start();

	session_unset(); // Unset The Data

	session_destroy();

	header('Location: index.php');
	exit();