<?php
	session_start();
	include 'connect.php';
	include 'header.php';

	if (!isset($_SESSION['userName'])) {
		header('location: index.php');
    	exit();
	}

if ($conn_status) {

	$sql_stam = "SELECT * FROM `user`
							JOIN `time_of_use`
							ON time_of_use.user = user.Sid WHERE `outTime` = '' ";

	$result = mysqli_query($conn_status, $sql_stam);

	if (mysqli_num_rows($result) >= 1) {
?><div class="container">
	<table>
		<h2>أسماء الطالبات المتواجدات داخل النادي</h2>
		<tr>
			<td>م</td>
			<td>اسم الطالبة</td>
			<td>الرقم الجامعي</td>
			<td>تسجيل الخروح من النادي</td>
		</tr>
		<?php
		while ($row = mysqli_fetch_assoc($result)) {
		?>
		<tr>
			<td><?php echo $row['Sid'] ?></td>
			<td><?php echo $row['name'] ?></td>
			<td><?php echo $row['University_ID'] ?></td>
			<td>
				<button><a href="logoutStu.php?stuid=<?php echo $row['Sid']; ?>">خروج</a></button>
			</td>
		<?php } ?>
		</tr>
	</table></div>
	<?php
	} else {
		echo '<h2>لا توجد طالبات داخل النادي</h2>';
	}
	?>

	<div class="container">
		<h3><button><a href="main.php">الصفحة الرئيسية</a></button></h3>
	</div>


<?php
include 'footer.php';

}else{
    echo "No connection";
	echo  mysqli_connect_error();
}
?>
