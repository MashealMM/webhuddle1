<?php
	session_start();
	include 'connect.php';
  include 'header.php';

	if (!isset($_SESSION['userName'])) {
		header('location: index.php');
    	exit();
	}

if ($conn_status) {

	if ($_SERVER['REQUEST_METHOD']=="POST"){

		$UId = $_POST['UId'];
		$user = $_POST['user'];

		$insert_stam = "INSERT INTO `user`(`Sid`, `name`, `University_ID`, `timeToLogin`) VALUES(NULL, '$user', '$UId', 0)";
		$result = mysqli_query($conn_status, $insert_stam);

		header('location: login.php');
		exit();
	}

?>

	<form action="signup.php" method= "POST">

        <h3>تسجيل طالبة جديدة</h3>
        <div class="test">
            <input type="text" name="UId" placeholder="الرقم الجامعي">
        </div>
				<div class="test">
            <input type="text" name="user" placeholder="اسم الطالبة">
        </div>
        <div class="test">
            <input type="submit" value="إضافة">
        </div>

    </form>

    <!-- تسجيل دخول طالبة لديها حساب -->
    <div>
			<a href="login.php">تسجيل الدخول</a>
		</div>

    <div>
  		<h3 class="text-center"><a href="main.php">الصفحة الرئيسية</a></h3>
  	</div>

<?php
include 'footer.php';

}else{
    echo "No connection";
	echo  mysqli_connect_error();
}
