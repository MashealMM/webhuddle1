<?php
	session_start();
	include 'connect.php';
	include 'header.php';

	if (!isset($_SESSION['userName'])) {
		header('location: index.php');
    	exit();
	}

if ($conn_status) {

	$sql_stam = "SELECT * FROM `user`";

	$result = mysqli_query($conn_status, $sql_stam);
	//$row = mysqli_fetch_assoc($result);


?>
	<div class="container">
<table >
    <h1>بيان بأوقات بقاء الطالبات داخل النادي</h1>
		<tr>
			<td>م</td>
			<td>اسم الطالبة</td>
			<td>الرقم الجامعي</td>
      <td> عدد مرات الدخول</td>
			<td> مدة البقاء داخل النادي</td>
      <td>الحالة</td>
		</tr>
    <?php
    while ($row = mysqli_fetch_assoc($result)) {
    ?>
    <tr>
      <td><?php echo $row['Sid']; ?></td>
      <td><?php echo $row['name']; ?></td>
      <td><?php echo $row['University_ID']; ?></td>
      <td><?php echo $row['timeToLogin']; ?></td>
      <?php
      // استخدم دالة الجمع عشان اطلع مجموع الأوقات اللي كانت فيها داخل النادي
        $count_stam = "SELECT SUM(Time) as total FROM `time_of_use` WHERE `user` = '$row[Sid]' ";
        $countResult = mysqli_query($conn_status, $count_stam);
        $rowcount = mysqli_fetch_assoc($countResult);

        // خزنت المجموع داخل متغير لانه راحع يطلع بصيغة التايمستامب ويبالي احوله لوقت عشان أقدر أقرأه
        $myTime = $rowcount['total'];
        $hour = $myTime / 3600 % 24;    // to get hours
        if ($hour < 10){
          $hour = '0'.$hour;
        }
  			$minute = $myTime / 60 % 60;    // to get minutes
        if ($minute < 10){
          $minute = '0'.$minute;
        }
  			$second = $myTime % 60;         // to get seconds
        if ($second < 10) {
          $second = '0'.$second;
        }
       ?>
      <td><?php echo $hour.':'.$minute.':'.$second;?></td>

			<?php
			// استعلام يوضح الطالبات المتواجدات داخل النادي حالياُّ من خلال قيمة وقت الخروج: إذا كانت فارغة فهي في النادي والعكس
			$check_stam = "SELECT `outTime` FROM `time_of_use` WHERE `user` = '$row[Sid]' ORDER BY `id` DESC LIMIT 1 ";
			$checkResult = mysqli_query($conn_status, $check_stam);
			$checkrow = mysqli_fetch_assoc($checkResult);
			?>

			<td><?php if ($checkrow['outTime'] == ''){
				echo '<a href="club.php"><b><u>داخل النادي</u></b></a>';
			} else {
				echo 'خارج النادي';
			} ?></td>

    </tr>
    <?php
    }
    ?><div class="container">
	</table></div>
  <div>
	 <h4 ><a href="login.php">دخول طالبة للنادي</a></h4>
	</div>
  <div>
	 <h4 ><a href="club.php">خروج طالبة من النادي</a></h4>
	</div>
  <div>
    <h4><a href="signup.php">تسجيل طالبة جديدة</a></h4>
  </div>

	<!--تسجيل خروج الادمن من البرنامج-->
	<div class="text-center">
  	<a href="logout.php">خروج</a>
	</div></div>

<?php
include 'footer.php';

}else{
    echo "No connection";
	echo  mysqli_connect_error();
}
?>
