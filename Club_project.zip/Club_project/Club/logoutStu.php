<?php
/*
صفحة خروج الطالبة من النادي
*/
	session_start();
	include 'connect.php';
	include 'header.php';

	if (!isset($_SESSION['userName'])) {
		header('location: index.php');
    	exit();
	}

if ($conn_status) {

	date_default_timezone_set('Asia/Riyadh');

	$stuid	= $_GET['stuid'];

	//Update The outTime Field In The DB
	$time 	= time();

	$updoutTime_stam = "UPDATE `time_of_use` SET `outTime`='$time'
						WHERE `user`='$stuid'
						ORDER BY id DESC LIMIT 1";
					
	$time_result = mysqli_query($conn_status, $updoutTime_stam);

	$timeOfUse_stam 	= "SELECT * FROM time_of_use
							WHERE `user` = '$stuid'
							ORDER BY id DESC LIMIT 1";
	$timeOfUse_result 	= mysqli_query($conn_status, $timeOfUse_stam);

      while ($row = mysqli_fetch_assoc($timeOfUse_result)) {
      	$sinTime 	= $row['inTime'];
      	$inTime 	= date('h:i:s', $sinTime);
      	//echo $inTime;
      	//echo'<br>';

      	$soutTime 	= $row['outTime'];
      	$outTime 	= date('h:i:s', $soutTime);
      	//echo $outTime;
      	//echo'<br>';

      	$myTime = $soutTime - $sinTime;

        $hour = $myTime / 3600 % 24;    // to get hours
  			$minute = $myTime / 60 % 60;    // to get minutes
  			$second = $myTime % 60;         // to get seconds

  			//echo $hour.':'.$minute.':'.$second;

  			$updTime_stam = "UPDATE `time_of_use` SET `Time`='$myTime'
  							WHERE `user`='$stuid'
  							ORDER BY id DESC LIMIT 1";
  			$useTime = mysqli_query($conn_status, $updTime_stam);

      }

			header('location: index.php');
			exit();


include 'footer.php';

}else{
  echo "No connection";
	echo  mysqli_connect_error();
}
